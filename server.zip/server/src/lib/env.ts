import dotenv from "dotenv";

dotenv.config();

const ENV = {
  NODE_ENV: process.env.NODE_ENV!,
  PORT: process.env.PORT!,
  UPSTASH_REDIS_URL: process.env.UPSTASH_REDIS_URL!,
  UPSTASH_REDIS_TOKEN: process.env.UPSTASH_REDIS_TOKEN!,
  CLOUDINARY_CLOUD_NAME: process.env.CLOUDINARY_CLOUD_NAME!,
  CLOUDINARY_API_KEY: process.env.CLOUDINARY_API_KEY!,
  CLOUDINARY_API_SECRET: process.env.CLOUDINARY_API_SECRET!,
  ACCESS_TOKEN_SECRET: process.env.ACCESS_TOKEN_SECRET!,
  REFRESH_TOKEN_SECRET: process.env.REFRESH_TOKEN_SECRET!,
  FRONTEND_LOCAL_URL: process.env.FRONTEND_LOCAL_URL!,
  FRONTEND_PROD_URL: process.env.FRONTEND_PROD_URL!,
  GEMINI_API_KEY: process.env.GEMINI_API_KEY!,
  QDRANT_API_KEY: process.env.QDRANT_API_KEY!,
  QDRANT_URL: process.env.QDRANT_URL!,
  QDRANT_COLLECTION: process.env.QDRANT_COLLECTION!,
};

export { ENV };
